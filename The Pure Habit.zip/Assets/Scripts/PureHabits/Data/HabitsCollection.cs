using System;

namespace PureHabits.Data
{
    [Serializable]
    public class HabitsCollection
    {
        public Habit[] Habits;
    }
}