using System;

namespace PureHabits.Data
{
    [Serializable]
    public class Profile
    {
        public int AvatarId;
        public string Name;
    }
}
