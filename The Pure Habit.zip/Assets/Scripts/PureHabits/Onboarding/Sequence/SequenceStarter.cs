﻿using System;
using PureHabits.Data;
using UnityEngine;

namespace PureHabits.Onboarding.Sequence
{
    public class SequenceStarter : MonoBehaviour
    {
        [SerializeField] private GameObject onbWindow;
        [SerializeField] private AbstractSequenceElement sequenceElement;
        [SerializeField] private DataStorage dataStorage;

        private void Awake()
        {
            dataStorage.ProfileLoaded += DataStorage_OnProfileLoaded;
        }

        private void OnDestroy()
        {
            dataStorage.ProfileLoaded -= DataStorage_OnProfileLoaded;
        }

        private void DataStorage_OnProfileLoaded(bool success, Data.Profile _)
        {
            onbWindow.SetActive(!success);
            
            if (!success)
                sequenceElement.ExecuteSequence();
        }
    }
}