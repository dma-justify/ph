﻿namespace Utils.Timer
{
    public interface ITimerView
    {
        void SetTime(int seconds);
    }
}