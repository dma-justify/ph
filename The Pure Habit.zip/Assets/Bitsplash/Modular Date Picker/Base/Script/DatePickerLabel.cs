﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using UnityEngine;

namespace Bitsplash.DatePicker
{
    public abstract class DatePickerLabel : MonoBehaviour
    {
        public abstract void SetText(string text);
    }
}