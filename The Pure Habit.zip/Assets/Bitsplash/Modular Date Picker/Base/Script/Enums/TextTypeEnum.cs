﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bitsplash.DatePicker
{
    public enum TextTypeEnum
    {
        StandardText,
        TextMeshPro
    }
}
